<?php
// created: 2024-03-07 10:26:49
$dictionary["CWMS_Businesses"]["fields"]["cwms_businesses_cwms_customer"] = array (
  'name' => 'cwms_businesses_cwms_customer',
  'type' => 'link',
  'relationship' => 'cwms_businesses_cwms_customer',
  'source' => 'non-db',
  'module' => 'CWMS_customer',
  'bean_name' => 'CWMS_customer',
  'side' => 'right',
  'vname' => 'LBL_CWMS_BUSINESSES_CWMS_CUSTOMER_FROM_CWMS_CUSTOMER_TITLE',
);
