<?php
// created: 2024-03-07 10:35:52
$dictionary["CWMS_Businesses"]["fields"]["cwms_owners_cwms_businesses"] = array (
  'name' => 'cwms_owners_cwms_businesses',
  'type' => 'link',
  'relationship' => 'cwms_owners_cwms_businesses',
  'source' => 'non-db',
  'module' => 'CWMS_Owners',
  'bean_name' => 'CWMS_Owners',
  'vname' => 'LBL_CWMS_OWNERS_CWMS_BUSINESSES_FROM_CWMS_OWNERS_TITLE',
);
