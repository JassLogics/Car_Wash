<?php
// created: 2024-03-07 10:35:52
$dictionary["CWMS_Businesses"]["fields"]["cwms_businesses_cwms_customers"] = array (
  'name' => 'cwms_businesses_cwms_customers',
  'type' => 'link',
  'relationship' => 'cwms_businesses_cwms_customers',
  'source' => 'non-db',
  'module' => 'CWMS_Customers',
  'bean_name' => 'CWMS_Customers',
  'side' => 'right',
  'vname' => 'LBL_CWMS_BUSINESSES_CWMS_CUSTOMERS_FROM_CWMS_CUSTOMERS_TITLE',
);
