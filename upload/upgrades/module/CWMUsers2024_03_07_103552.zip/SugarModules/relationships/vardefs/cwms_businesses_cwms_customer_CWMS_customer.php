<?php
// created: 2024-03-07 10:26:49
$dictionary["CWMS_customer"]["fields"]["cwms_businesses_cwms_customer"] = array (
  'name' => 'cwms_businesses_cwms_customer',
  'type' => 'link',
  'relationship' => 'cwms_businesses_cwms_customer',
  'source' => 'non-db',
  'module' => 'CWMS_Businesses',
  'bean_name' => false,
  'vname' => 'LBL_CWMS_BUSINESSES_CWMS_CUSTOMER_FROM_CWMS_BUSINESSES_TITLE',
  'id_name' => 'cwms_businesses_cwms_customercwms_businesses_ida',
);
$dictionary["CWMS_customer"]["fields"]["cwms_businesses_cwms_customer_name"] = array (
  'name' => 'cwms_businesses_cwms_customer_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CWMS_BUSINESSES_CWMS_CUSTOMER_FROM_CWMS_BUSINESSES_TITLE',
  'save' => true,
  'id_name' => 'cwms_businesses_cwms_customercwms_businesses_ida',
  'link' => 'cwms_businesses_cwms_customer',
  'table' => 'cwms_businesses',
  'module' => 'CWMS_Businesses',
  'rname' => 'name',
);
$dictionary["CWMS_customer"]["fields"]["cwms_businesses_cwms_customercwms_businesses_ida"] = array (
  'name' => 'cwms_businesses_cwms_customercwms_businesses_ida',
  'type' => 'link',
  'relationship' => 'cwms_businesses_cwms_customer',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CWMS_BUSINESSES_CWMS_CUSTOMER_FROM_CWMS_CUSTOMER_TITLE',
);
