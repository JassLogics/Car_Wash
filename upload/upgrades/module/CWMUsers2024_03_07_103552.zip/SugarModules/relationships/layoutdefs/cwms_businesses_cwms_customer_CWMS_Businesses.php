<?php
 // created: 2024-03-07 10:26:49
$layout_defs["CWMS_Businesses"]["subpanel_setup"]['cwms_businesses_cwms_customer'] = array (
  'order' => 100,
  'module' => 'CWMS_customer',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CWMS_BUSINESSES_CWMS_CUSTOMER_FROM_CWMS_CUSTOMER_TITLE',
  'get_subpanel_data' => 'cwms_businesses_cwms_customer',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
