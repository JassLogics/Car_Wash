<?php
// created: 2024-03-07 04:52:01
$dictionary["CWMS_vendor"]["fields"]["cwms_owner_cwms_vendor"] = array (
  'name' => 'cwms_owner_cwms_vendor',
  'type' => 'link',
  'relationship' => 'cwms_owner_cwms_vendor',
  'source' => 'non-db',
  'module' => 'CWMS_Owner',
  'bean_name' => 'CWMS_Owner',
  'vname' => 'LBL_CWMS_OWNER_CWMS_VENDOR_FROM_CWMS_OWNER_TITLE',
);
