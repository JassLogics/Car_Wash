<?php
// created: 2024-03-07 04:52:02
$dictionary["CWMS_vendor"]["fields"]["cwms_vendor_cwms_customer"] = array (
  'name' => 'cwms_vendor_cwms_customer',
  'type' => 'link',
  'relationship' => 'cwms_vendor_cwms_customer',
  'source' => 'non-db',
  'module' => 'CWMS_customer',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_CWMS_VENDOR_CWMS_CUSTOMER_FROM_CWMS_CUSTOMER_TITLE',
);
